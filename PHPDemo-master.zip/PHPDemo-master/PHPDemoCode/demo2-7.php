<?php
	//默认参数函数--->python
	function demo($name="张三",$age=12,$sex="男"){
		echo "姓名：".$name.",年龄:".$age.".性别：".$sex;
	}
	//demo("张三",45,"女");
	//demo();
	//demo("李四");
	demo("李四",34);
?>