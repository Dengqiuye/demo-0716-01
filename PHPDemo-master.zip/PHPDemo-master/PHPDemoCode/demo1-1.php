<?php
	//定义常量
	/*定义常量*/
	#定义常量
	//char[] GREETING='hello world!'
	define("GREETING", "hello world!",true);//让常量的名称大小写不敏感
	echo GREETING;
	echo "<br>";//回车换行
	echo greeting;
?>