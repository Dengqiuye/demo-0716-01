<?php
	$a = 1;
	while ($a<=0) {
		# code...
		$a++;
	}
	// do{
	// 	$a++;
	// }while($a<0);
	echo "a =".$a;
?>