<?php
	$x = 2;
	//$y = $x++;//先“使用”，然后再加1
	echo "<br>x =".++$x;
	echo "<br>x =".$x;
?>