<?php
	//数组
	$arr = array(1,3,8,2,10,12,11);
	print_r($arr);
	sort($arr);
	print_r($arr);
?>