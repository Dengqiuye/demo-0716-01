<?php
	//定义变量
	//int a=10;
	$number = 10;
	echo $number;
	$result = $number;
	echo "<br>";
	echo "result=".$result;
?>