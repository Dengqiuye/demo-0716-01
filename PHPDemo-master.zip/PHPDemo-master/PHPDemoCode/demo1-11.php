<?php
//	奇偶数判断
	$a = 23;
	if($a%2 ==0){
		echo "a是偶数。";
	}else{
		echo "a是奇数";
	}
?>